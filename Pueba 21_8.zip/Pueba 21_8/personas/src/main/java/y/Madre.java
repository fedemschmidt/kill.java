package y;

import java.util.HashSet;

public class Madre extends Persona{
    String empresa;
    HashSet <Hijo> hijos = new HashSet <Hijo>();

    public Madre(){
        super();
    }

    public void setEmpresa(String e){
        this.empresa = e;
    }

    public void addHijos(Hijo a){
        hijos.add(a);
    }

    public String getEmpresa(){
        return this.empresa;
    }

    public HashSet <Hijo> getHijos(){
        return this.hijos;
    }

    public HashSet <Hijo> hijosMenores(){
        HashSet <Hijo> hmenores = new HashSet <Hijo>();
        for (Hijo i : this.hijos) {
            if(i.getEdad()>18) hmenores.add(i);
        }
        return hmenores;
    }

    public void mostrarPersona(){
        super.mostrarPersona();
        System.out.println(this.empresa);
        for (Hijo i : this.hijos) {
            System.out.println(i.getNombre());
        }
    }
}