package y;

public class Libro{
    private int p;
    private Editorial editorial;

    public Libro(){

    }

    public Libro(int a, Editorial b){
        this.p = a;
        this.editorial = b;
    }

    public void setPrecio(int pr){
        this.p = pr;
    }

    public void setEditorial(Editorial i){
        this.editorial = i;
    }

    public int getPrecio(){
        return this.p;
    }

    public Editorial getEditorial(){
        return this.editorial;
    }
}