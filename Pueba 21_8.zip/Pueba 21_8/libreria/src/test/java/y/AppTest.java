package y;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AppTest {
    @Test
    public void Test1(){
        Libreria b = new Libreria();
        Libro l1 = new Libro(100, Editorial.ALIANZA);
        b.setVentas();
        b.addLibro(l1);
        assertTrue( b.getVentas(Editorial.ALIANZA) == 1 );
    }

    @Test
    public void Test2(){
        Libreria b = new Libreria();
        Libro l1 = new Libro(100, Editorial.ALIANZA);
        Libro l2 = new Libro(100, Editorial.KAPELUZ);
        Libro l3 = new Libro(100, Editorial.ATLÁNTIDA);
        Libro l4 = new Libro(100, Editorial.INTERZONA);
        Libro l5 = new Libro(100, Editorial.KAPELUZ);
        Libro l6 = new Libro(100, Editorial.SUDAMERICA);
        Libro l7 = new Libro(100, Editorial.SUR);
        b.setVentas();
        b.addLibro(l1);
        b.addLibro(l2);
        b.addLibro(l3);
        b.addLibro(l4);
        b.addLibro(l5);
        b.addLibro(l6);
        b.addLibro(l7);
        assertTrue(b.masVentas() == Editorial.KAPELUZ);
    }
}
