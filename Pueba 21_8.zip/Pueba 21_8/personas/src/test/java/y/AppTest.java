package y;

import static org.junit.Assert.assertTrue;

import org.junit.Test;

public class AppTest 
{
    @Test
    public void Test1()
    {
        Persona p = new Persona("Pamela", "David", 19, 36152413, "Mujer", "Provedora de servicios de caracter carnal");
        
        assertTrue(p.mayorEdad()==true);
    }

    @Test
    public void Test2()
    {
        Persona p = new Persona("Pamela", "David", 19, 36152413, "Mujer", "Provedora de servicios de caracter carnal");
        
        assertTrue(p.nombreConA()==true);
    }

    @Test
    public void Test3()
    {
        Persona p = new Persona("Pamela", "David", 19, 36152413, "Mujer", "Provedora de servicios de caracter carnal");
        
        assertTrue(p.dniMenor38kk()==true);
    }

    @Test
    public void Test4()
    {
        Hijo ph = new Hijo("Marco", "David", 5, 39856429, "Hombre", "-", "IPM-kinder", "Plasa sesamo se va al infierno - el juego");
        Madre m = new Madre();
        m.setEmpresa("empresa");
        m.addHijos(ph);
        
        assertTrue(m.hijosMenores().contains(ph));
    }
}
