package y;

public class Hijo extends Persona{
    String escuela;
    String juego;

    public Hijo(){
        super();
    }

    public Hijo(String n, String a, int e, long d, String s, String o, String es, String j){
        super();
        escuela = es;
        juego = j;
    }

    public void setEscuela(String es){
        this.escuela=es;
    }

    public void setJuego(String j){
        this.juego=j;
    }

    public void mostrarPersona(){
        super.mostrarPersona();
        System.out.println(this.escuela);
        System.out.println(this.juego);
    }
}