package y;
public class Persona{
    private String nombre;
    private String apellido;
    private int edad;
    private long dni;
    private String sexo;
    private String ocupacion;
    
    public Persona(){
        this("Juan","Nuñez",35, 39251625L, "Masculino", "Albañil");
    }

    public Persona(String n, String a, int e, long d, String s, String o){
        this.nombre = n;
        this.apellido = a;
        this.edad = e;
        this.dni = d;
        this.sexo = s;
        this.ocupacion = o;
    }

    public void setNombre(String n){
        this.nombre = n;
    }
    public void setApellido(String a){
        this.apellido = a;
    }
    public void setEdad(int e){
        this.edad = e;
    }
    public void setDni(long d){
        this. dni = d;
    }
    public void setSexo(String s){
        this.sexo = s;
    }
    public void setOcupacion(String o){
        this.ocupacion = o;
    }

    public String getNombre(){
        return this.nombre;
    }
    public String getApellido(){
        return this.apellido;
    }
    public int getEdad(){
        return this.edad;
    }
    public long getDni(){
        return this.dni;
    }
    public String getSexo(){
        return this.sexo;
    }
    public String getOcupacion(){
        return this.ocupacion;
    }

    public boolean mayorEdad(){
        boolean a;
        if(this.edad>=18) a = true;
        else a = false;
        return a;
    }

    public boolean nombreConA(){
        String temp = this.nombre;
        boolean a=false;
        for(int i=temp.length(); i!=0; i--){
            if(temp.contains("a")){
                a = true;
                break;
            }
        }
        return a;
    }

    public boolean dniMenor38kk(){
        boolean a=false;
        if(this.dni<38000000) a = true;
        else a = false;
        return a;
    }

    public void mostrarPersona(){
        System.out.println(this.nombre);
        System.out.println(this.apellido);
        System.out.println(this.edad);
        System.out.println(this.dni);
        System.out.println(this.sexo);
        System.out.println(this.ocupacion);
    }
}