package y;

public enum Editorial{
    KAPELUZ, SUDAMERICA, ATLÁNTIDA, EL_ATENEO, INTERZONA, SUR, ALIANZA;
}