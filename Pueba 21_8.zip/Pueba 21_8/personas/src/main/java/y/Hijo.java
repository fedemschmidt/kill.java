package y;

public class Hijo extends Persona{
    private String escuela;
    private String juego;

    public Hijo(){
        super();
    }

    public Hijo(String n, String a, int e, long d, String s, String o, String es, String j){
        super();
        escuela = es;
        juego = j;
    }

    public void setEscuela(String es){
        this.escuela=es;
    }

    public void setJuego(String j){
        this.juego=j;
    }

    public String getEscuela(){
        return this.escuela;
    }

    public String getJuego(){
        return this.juego;
    }

    public void mostrarPersona(){
        super.mostrarPersona();
        System.out.println(this.escuela);
        System.out.println(this.juego);
    }
}
