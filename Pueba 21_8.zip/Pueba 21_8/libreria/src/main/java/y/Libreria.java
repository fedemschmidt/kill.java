package y;

import java.util.HashMap;
import java.util.HashSet;

public class Libreria{
    HashSet <Libro> libros = new HashSet<Libro>();
    HashMap <Editorial, Integer> ventas = new HashMap<Editorial, Integer>();

    public Libreria(){

    }

    public void setVentas(){
        ventas.put(Editorial.ALIANZA, 0);
        ventas.put(Editorial.ATLÁNTIDA, 0);
        ventas.put(Editorial.EL_ATENEO, 0);
        ventas.put(Editorial.INTERZONA, 0);
        ventas.put(Editorial.KAPELUZ, 0);
        ventas.put(Editorial.SUDAMERICA, 0);
        ventas.put(Editorial.SUR, 0);
    }

    public void addLibro(Libro a){
        libros.add(a);
        ventas.put(a.getEditorial(), ventas.get(a.getEditorial())+1);
    }

    public int getVentas(Editorial e){
        return ventas.get(e);
    }

    public Editorial masVentas(){
        Editorial[] editoriales = Editorial.values();
        int a = ventas.get(editoriales[0]);
        Editorial e = editoriales[0];
        for(int i = 1; i != ventas.size(); i++){
            if(ventas.get(editoriales[i]) > a){
                a = ventas.get(editoriales[i]);
                e = editoriales[i];
            }
        }
        return e;
    }


}